  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  		Demo for tensor_gee.m	   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Goal:
% Fit tensor gee for 2d image "cross" ("device5-20.gif" in the folder "TensorGEE")
% To load the function, click "Set Path" in Matlab and choose "add with subfolders" for the folder "TensorGEE"

% generate data
n=50;
m=10;
shape = imread('device5-20.gif');	
shape = array_resize(shape,[32,32]); % 32-by-32
b = zeros(2*size(shape));
b((size(b,1)/4):(size(b,1)/4)+size(shape,1)-1,(size(b,2)/4):(size(b,2)/4)+size(shape,2)-1) = shape;
[p1,p2] = size(b);
p0 = 5;
b0 = ones(p0,1);
X = randn(n*m,p0);
M = tensor(randn(p1,p2,n*m)); 
mu = X*b0 + double(ttt(tensor(b), M, 1:2));
S=0.8.*ones(m)+0.2.*eye(m); %����Э����Ϊ1,0.8�� ����Ϊ0
sigma=3;
S=sigma.*kron(eye(n),S);
y=mvnrnd(mu,S)';
%%
% fit
r=3;
id=kron(1:n,ones(1,m))';
time=kron(ones(1,n),1:m)';
%penalty='enet';
penalty='scad';
workcorr='unstructured';
lambda = 2^(-3);
[beta0hat,betahat,alphahat,devhat] =tensor_gee(X,M,y,r,id,time,workcorr,lambda,penalty);
ypred=X*beta0hat + double(ttt(tensor(betahat), M, 1:2));
corr(ypred,y)  %correlation of prediction
sum((y-ypred).^2)  % square L2 loss
%%
% plot 
 figure; hold on;
 set(gca,'FontSize',20);
 subplot(1,1,1);
 imagesc(-double(betahat));
 colormap(gray);
 title({'n= '});
 ylabel('regularization');
 axis equal;
 axis tight;