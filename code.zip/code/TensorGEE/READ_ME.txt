The main function is tensor_gee.m, other folders are dependency.
To load the function, click "Set Path" in Matlab and choose "add with subfolders" for the folder "TensorGEE"

The function call is 
	[beta0hat,betahat,alphahat,devhat] = tensor_gee(X,M,y,r,id,time,workcorr,lambda,penalty)

Input
X: vector covariate, (n*m)-by-p0 matrix, n is # of subjects, m is # of time points, p0 is # of vector covariate
M: tensor covariate, for 2d image can be created by tensor(randn(p1,p2,n*m)), (p1,p2) is the image size
y: response, n*m-by-1 vector
r: rank of CP decomposition
id: id for each sample, n*m-by-1 vector, samples from the same subject share the same id
time: observed time for each sample, n*m-by-1 vector. For correlation doesn't depend on time (equicorr,ar,indep), this can be anything
workcorr: one of {'equicorr','AR1','indep','unstructured'}, though sometimes 'unstructured' fails (singular matrix)
lambda: tuing parameter for penalty. For non-regularized one, set lambda = 1e-20. (lambda = 0 gives singular matrix) 
penalty: 'enet' for lasso and 'scad' for scad

Output
beta0hat: coefficients for vector covariate, p0-by-1 vector
betahat: coefficients for tensor covariate, p1-by-p2 ktensor
alphahat: coefficients for correlation structure
devhat: deviance 

For a demo example, see demo.m
