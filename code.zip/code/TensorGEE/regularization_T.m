clear all;clc;
imgfiles = { ...
'device8-20.gif'; ...   % T shape
};
tune=2.^[-5:3];
nlist=[75 100 125 150];
select=cell(length(nlist),1);
s = RandStream('mt19937ar','Seed',33);
RandStream.setGlobalStream(s);
for i=1:length(nlist)
	n=nlist(i);
	m=4;
	shape = imread(imgfiles{3}); 
	shape = array_resize(shape,[32,32]); % 32-by-32
	b = zeros(2*size(shape));
	b((size(b,1)/4):(size(b,1)/4)+size(shape,1)-1,(size(b,2)/4):(size(b,2)/4)+size(shape,2)-1) = shape;
	[p1,p2] = size(b);
	%vector signal
	p0 = 5;
	b0 = ones(p0,1);
	%covariates
	X = randn(n*m,p0);
	M = tensor(randn(p1,p2,n*m)); 
	%simulated response
	mu = X*b0 + double(ttt(tensor(b), M, 1:2));
	S=0.8.*ones(m)+0.2.*eye(m);
	%signal-noise ratio
	sigma=1;
	S=sigma.*kron(eye(n),S);
	y=mvnrnd(mu,S)';
	%input for main function
	r=2;
	id=kron(1:n,ones(1,m))';
	time=kron(ones(1,n),[6,12,18,24])';
	%penalty='enet';
	penalty='scad';
	workcorr='equicorr';
	%test data for tuning
	Xtest = randn(n*m,p0);
	Mtest = tensor(randn(p1,p2,n*m)); 
	mutest = Xtest*b0 + double(ttt(tensor(b), Mtest, 1:2));
	ytest=mvnrnd(mutest,S)';
	dev_tune=inf;
	for j=1:length(tune)
		lambda=tune(j);
		[beta0hat,betahat,alphahat,devhat] =tensor_gee(X,M,y,r,id,time,workcorr,lambda,penalty);
		ypred=Xtest*beta0hat + double(ttt(tensor(betahat), Mtest, 1:2));
		dev=sum((ytest-ypred).^2);
		if dev<dev_tune
			dev_tune=dev;
			beta0gee=beta0hat;
			betagee=betahat;
		end
	end
	select{i,1}=betagee;
end
save penalize_Tshape;
	
lambda=1e-20;
noreg=cell(length(nlist),1);
for i=1:length(nlist)
	n=nlist(i);
	m=4;
	shape = imread(imgfiles{3}); 
	shape = array_resize(shape,[32,32]); % 32-by-32
	b = zeros(2*size(shape));
	b((size(b,1)/4):(size(b,1)/4)+size(shape,1)-1,(size(b,2)/4):(size(b,2)/4)+size(shape,2)-1) = shape;
	[p1,p2] = size(b);
	%vector signal
	p0 = 5;
	b0 = ones(p0,1);
	%covariates
	X = randn(n*m,p0);
	M = tensor(randn(p1,p2,n*m)); 
	%simulated response
	mu = X*b0 + double(ttt(tensor(b), M, 1:2));
	S=0.8.*ones(m)+0.2.*eye(m);
	%signal-noise ratio
	sigma=1;
	S=sigma.*kron(eye(n),S);
	y=mvnrnd(mu,S)';
	%input for main function
	r=2;
	id=kron(1:n,ones(1,m))';
	time=kron(ones(1,n),[6,12,18,24])';
	penalty='enet';
	workcorr='equicorr';
	[beta0hat,betahat,alphahat,devhat] =tensor_gee(X,M,y,r,id,time,workcorr,lambda,penalty);
	noreg{i,1}=betahat;
end
save unpenalize_Tshape;

