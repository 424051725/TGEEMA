%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  		Demo for tensor_gee.m	   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Goal:
% Fit tensor gee for 2d image "cross" ("device5-20.gif" in the folder "TensorGEE")
% To load the function, click "Set Path" in Matlab and choose "add with subfolders" for the folder "TensorGEE"

% generate data

n = 150;
m = 4;
bindex = 5;
dims = 16;
err = 'mixgaussian';
[X,M,y,id,time,b] = gen_func(n,m,bindex,dims,err);


% fit
r=3;
%penalty='enet';
penalty='scad';
workcorr='equicorr';
lambda = 0;
[beta0hat,betahat,alphahat,devhat] =tensor_gee(X,M,y,r,id,time,workcorr,lambda,penalty);
ypred=X*beta0hat + double(ttt(tensor(betahat), M, 1:2));
% norm(tensor(betahat).data - b, 'f')
norm(tensor(betahat) - b)
norm(beta0hat - beta0)
% corr(ypred,y)  %correlation of prediction
% sum((y-ypred).^2)  % square L2 loss

% plot 
 figure; hold on;
 set(gca,'FontSize',20);
 subplot(1,1,1);
 imagesc(-double(betahat));
 colormap(gray);
 title({'n= '});
 ylabel('regularization');
 axis equal;
 axis tight;