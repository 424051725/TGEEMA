%% 2D simulation
clear
clc
%% setting parameters
n=200;
m=4;
max_rank=5;
fold = 5;
workcorr='equicorr'; %  'equicorr', 'AR1', 'unstructured'
link='normal';
%% generate data and run main code
for pic_name = 1:1:2
    for repeat = 1:1:1
        run('data_2d.m');
        run('simulation_func.m');
    end
end


